package com.example.ovs40.Fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import com.example.ovs.createElection
import com.example.ovs.output
import com.example.ovs.send
import com.example.ovs3.positions
import com.example.ovs40.AddPositionPage
import com.example.ovs40.R
import com.google.android.material.textfield.TextInputEditText

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [CreateElectionFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class CreateElectionFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_create_election, container, false)
        val positionPage = view?.findViewById<TextView>(R.id.add_positions)
        val electionName = view?.findViewById<TextInputEditText>(R.id.electionName)
        val school = view?.findViewById<TextInputEditText>(R.id.school)
        val date = view?.findViewById<TextInputEditText>(R.id.date)
        val startTime = view?.findViewById<TextInputEditText>(R.id.startingtime)
        val stopTime = view?.findViewById<TextInputEditText>(R.id.stoptime)
        val submit = view?.findViewById<Button>(R.id.createElection)
        submit?.setOnClickListener {
            val send = createElection(
                output,"${electionName?.text.toString()},${school?.text.toString()},${date?.text.toString()},${startTime?.text.toString()},${stopTime?.text.toString()}")
            send(output, "add positions,${positions}")



        }
        positionPage?.setOnClickListener {
            val selectPositions = Intent(activity, AddPositionPage::class.java)
            startActivity(selectPositions)

        }
        return view
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment CreateElectionFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            CreateElectionFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}