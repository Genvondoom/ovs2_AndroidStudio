package com.example.ovs40

class ElectionAdapterDataClass(var imageResource: Int, var text1: String, var text2: String)
