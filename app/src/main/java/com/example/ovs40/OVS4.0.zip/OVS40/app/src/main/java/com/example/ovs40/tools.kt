package com.example.ovs3

import android.hardware.biometrics.BiometricManager
import java.util.Collections.list

var mark= mutableListOf<List<String>>()
var electDetail = mutableListOf<String>()
var positions= mutableListOf<String>()
var positions2= mutableListOf<List<String>>()
var candidates = mutableListOf<List<String>>()
var choice= mutableListOf<String>()